---
name: bakery-morning-report
description: Write the Sunrise Bakery morning report for Maya from the Sales log, Inventory and This week files in the Sunrise Bakery Google Drive folder. Use when asked for the morning report, daily bakery summary, stock check, or reorder drafts.
---

# Sunrise Bakery morning report

## Inputs (all in the "Sunrise Bakery" Google Drive folder)
- Sunrise Bakery - Sales log (Google Sheet, one row per product per day, grows every evening)
- Sunrise Bakery - Inventory (Google Sheet, updated every evening for key items)
- Sunrise Bakery - This week (Google Doc, special orders and notes, updated every Monday)
- Sunrise Bakery - Handbook (Google Doc, the rules)

Always read the latest version from Drive. Do not use old copies from earlier chats.

## Steps
1. Find the most recent date in the Sales log. That is "yesterday".
2. Calculate yesterday's total revenue, units sold and units wasted per product.
3. Flag any product where waste is above 25% of units baked.
4. Flag any product that sold more than 95% of units baked. Suggest baking more.
5. Look across all days for a weekday pattern (for example, one weekday with much more waste). If today is that weekday, say it first.
6. Check the Inventory. Any ingredient where on_hand is at or below reorder_point is a stock alert.
7. Check last_counted. If a key item (count_daily = yes) was not counted yesterday, warn that its number may be old.
8. Read "This week". Add special orders to the normal bake and mention closures.
9. For each stock alert, create a Gmail DRAFT to the supplier.
   Reorder quantity = 3 x reorder_point. Sign as "Maya, Sunrise Bakery and Cafe".

## Output format (under 200 words)
**Today's #1 thing:** one sentence.

**Stock alerts**
- ingredient - on hand vs reorder point - supplier - draft created

**Yesterday in numbers**
- Revenue, best seller, biggest waste

**This week**
- Special orders and closures, with what to bake

**One idea**
- One practical change, based on the data.

## Rules
- Never send an email. Drafts only.
- Plain words. Maya reads this on her phone.
